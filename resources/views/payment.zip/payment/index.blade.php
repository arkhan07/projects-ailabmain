@extends('layouts.auth')
@push('title', get_phrase('Checkout'))
@push('css')
<style>
    .checkout-wrapper {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px 20px;
        position: relative;
        overflow: hidden;
    }

    .checkout-container {
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
        position: relative;
        z-index: 2;
    }

    .checkout-card {
        background: rgba(255, 255, 255, 0.03);
        backdrop-filter: blur(20px);
        border-radius: 24px;
        padding: 40px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
    }

    .checkout-header {
        text-align: center;
        margin-bottom: 40px;
    }

    .checkout-title {
        font-size: 32px;
        font-weight: 700;
        color: #fff;
        margin-bottom: 8px;
    }

    .checkout-subtitle {
        font-size: 16px;
        color: rgba(255, 255, 255, 0.6);
    }

    .checkout-content {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 40px;
    }

    .payment-methods {
        background: rgba(255, 255, 255, 0.02);
        border-radius: 16px;
        padding: 24px;
        border: 1px solid rgba(255, 255, 255, 0.05);
    }

    .payment-methods-title {
        font-size: 18px;
        font-weight: 600;
        color: #fff;
        margin-bottom: 20px;
    }

    .payment-method {
        background: rgba(255, 255, 255, 0.03);
        border: 2px solid rgba(255, 255, 255, 0.1);
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 12px;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 16px;
    }

    .payment-method:hover {
        background: rgba(255, 255, 255, 0.05);
        border-color: var(--color-cyan);
        transform: translateX(4px);
    }

    .payment-method.active {
        background: rgba(0, 255, 255, 0.05);
        border-color: var(--color-cyan);
        box-shadow: 0 0 20px rgba(0, 255, 255, 0.2);
    }

    .payment-method-logo {
        width: 80px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255, 255, 255, 0.95);
        border-radius: 8px;
        padding: 8px;
    }

    .payment-method-logo img {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
    }

    .payment-method-info {
        flex: 1;
    }

    .payment-method-name {
        font-size: 16px;
        font-weight: 600;
        color: #fff;
        margin: 0;
    }

    .order-summary {
        background: rgba(255, 255, 255, 0.02);
        border-radius: 16px;
        padding: 24px;
        border: 1px solid rgba(255, 255, 255, 0.05);
    }

    .order-summary-title {
        font-size: 18px;
        font-weight: 600;
        color: #fff;
        margin-bottom: 20px;
    }

    .order-item {
        padding: 16px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .order-item:last-child {
        border-bottom: none;
    }

    .order-item-header {
        display: flex;
        justify-content: space-between;
        align-items: start;
        margin-bottom: 8px;
    }

    .order-item-number {
        font-size: 12px;
        color: var(--color-cyan);
        font-weight: 600;
    }

    .order-item-title {
        font-size: 15px;
        color: #fff;
        font-weight: 500;
        margin: 0;
        flex: 1;
        padding: 0 12px;
    }

    .order-item-price {
        font-size: 16px;
        font-weight: 700;
        color: #fff;
        white-space: nowrap;
    }

    .order-item-price del {
        font-size: 13px;
        color: rgba(255, 255, 255, 0.4);
        margin-right: 8px;
    }

    .order-totals {
        margin-top: 24px;
        padding-top: 24px;
        border-top: 2px solid rgba(255, 255, 255, 0.1);
    }

    .total-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 12px;
        font-size: 15px;
    }

    .total-row-label {
        color: rgba(255, 255, 255, 0.7);
    }

    .total-row-value {
        color: #fff;
        font-weight: 600;
    }

    .total-row.highlight {
        font-size: 14px;
        color: var(--color-cyan);
    }

    .total-row.grand-total {
        font-size: 20px;
        font-weight: 700;
        margin-top: 16px;
        padding-top: 16px;
        border-top: 2px solid rgba(255, 255, 255, 0.1);
    }

    .total-row.grand-total .total-row-label {
        color: #fff;
    }

    .total-row.grand-total .total-row-value {
        color: var(--color-cyan);
    }

    .checkout-actions {
        margin-top: 32px;
        display: flex;
        gap: 12px;
    }

    .btn-checkout {
        flex: 1;
        padding: 16px 32px;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 600;
        border: none;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }

    .btn-checkout-primary {
        background: linear-gradient(135deg, var(--color-cyan) 0%, var(--color-blue) 100%);
        color: var(--color-dark);
    }

    .btn-checkout-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(0, 255, 255, 0.4);
    }

    .btn-checkout-secondary {
        background: rgba(255, 255, 255, 0.05);
        color: #fff;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .btn-checkout-secondary:hover {
        background: rgba(255, 255, 255, 0.1);
    }

    .payment-form-container {
        display: none;
        margin-top: 24px;
        padding: 24px;
        background: rgba(255, 255, 255, 0.02);
        border-radius: 12px;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }

    /* Payment Gateway Form Styling */
    .payment-form-container form button[type="submit"],
    .payment-form-container form .btn-primary,
    .payment-form-container form .eBtn {
        background: linear-gradient(135deg, var(--color-cyan) 0%, var(--color-blue) 100%) !important;
        color: var(--color-dark) !important;
        border: none !important;
        padding: 12px 24px !important;
        border-radius: 8px !important;
        font-weight: 600 !important;
        transition: all 0.3s ease !important;
    }

    .payment-form-container form button[type="submit"]:hover,
    .payment-form-container form .btn-primary:hover,
    .payment-form-container form .eBtn:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 24px rgba(0, 255, 255, 0.4) !important;
    }

    .payment-form-container .form-control,
    .payment-form-container input,
    .payment-form-container select,
    .payment-form-container textarea {
        background: rgba(255, 255, 255, 0.05) !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        color: #fff !important;
        border-radius: 8px !important;
        padding: 10px 16px !important;
    }

    .payment-form-container .form-control:focus,
    .payment-form-container input:focus,
    .payment-form-container select:focus,
    .payment-form-container textarea:focus {
        border-color: var(--color-cyan) !important;
        box-shadow: 0 0 0 2px rgba(0, 255, 255, 0.1) !important;
        outline: none !important;
    }

    .payment-form-container label {
        color: rgba(255, 255, 255, 0.8) !important;
        font-weight: 500 !important;
        margin-bottom: 8px !important;
    }

    .payment-form-container .text-muted,
    .payment-form-container small {
        color: rgba(255, 255, 255, 0.6) !important;
    }

    /* Payment Gateway Specific Overrides */
    #payment-form-container {
        color: #fff;
    }

    #payment-form-container h1,
    #payment-form-container h2,
    #payment-form-container h3,
    #payment-form-container h4,
    #payment-form-container h5,
    #payment-form-container h6 {
        color: #fff !important;
    }

    #payment-form-container p {
        color: rgba(255, 255, 255, 0.8) !important;
    }

    #payment-form-container .card,
    #payment-form-container .panel {
        background: rgba(255, 255, 255, 0.02) !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        border-radius: 12px !important;
    }

    .payment-form-container.active {
        display: block;
    }

    @media (max-width: 991px) {
        .checkout-content {
            grid-template-columns: 1fr;
            gap: 24px;
        }

        .checkout-card {
            padding: 24px;
        }

        .checkout-title {
            font-size: 24px;
        }
    }

    @media (max-width: 575px) {
        .checkout-actions {
            flex-direction: column-reverse;
        }

        .order-item-header {
            flex-direction: column;
            gap: 8px;
        }

        .order-item-title {
            padding: 0;
        }
    }
</style>
@endpush

@section('content')
<div class="checkout-wrapper">
    <div class="bg-gradient bg-gradient-top"></div>
    <div class="bg-gradient bg-gradient-bottom"></div>

    <div class="checkout-container">
        <div class="checkout-card">
            <div class="checkout-header">
                <h1 class="checkout-title">{{ get_phrase('Checkout') }}</h1>
                <p class="checkout-subtitle">{{ get_phrase('Review your order and complete payment') }}</p>
            </div>

            <div class="checkout-content">
                <!-- Payment Methods -->
                <div class="payment-methods">
                    <h2 class="payment-methods-title">{{ get_phrase('Select Payment Method') }}</h2>

                    @foreach ($payment_gateways as $key => $payment_gateway)
                        <div class="payment-method {{ $key == 0 ? 'active' : '' }}"
                             onclick="selectPaymentMethod('{{ $payment_gateway->identifier }}')"
                             id="{{ $payment_gateway->identifier }}-tab"
                             data-bs-toggle="pill"
                             data-bs-target="#{{ $payment_gateway->identifier }}"
                             role="tab">
                            <div class="payment-method-logo">
                                <img src="{{ get_image('assets/payment/' . $payment_gateway->identifier . '.png') }}"
                                     alt="{{ $payment_gateway->title }}" />
                            </div>
                            <div class="payment-method-info">
                                <p class="payment-method-name">{{ $payment_gateway->title }}</p>
                            </div>
                        </div>
                    @endforeach
                </div>

                <!-- Order Summary -->
                <div class="order-summary">
                    <h2 class="order-summary-title">{{ get_phrase('Order Summary') }}</h2>

                    <!-- Items List -->
                    <div class="order-items">
                        @foreach ($payment_details['items'] as $key => $item)
                            <div class="order-item">
                                <div class="order-item-header">
                                    <span class="order-item-number">#{{ $key + 1 }}</span>
                                    <p class="order-item-title">{{ $item['title'] }}</p>
                                    <div class="order-item-price">
                                        @if ($item['discount_price'] > 0)
                                            <del>{{ currency($item['price']) }}</del>
                                            {{ currency($item['discount_price']) }}
                                        @else
                                            {{ currency($item['price']) }}
                                        @endif
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>

                    <!-- Totals -->
                    <div class="order-totals">
                        @php
                            $payable = $payment_details['payable_amount'];
                            if (isset($payment_details['custom_field']['coupon_discount'])) {
                                $payable = $payment_details['payable_amount'] + $payment_details['custom_field']['coupon_discount'];
                            }
                            $payable = $payable - $payment_details['tax'];
                            if (isset($payment_details['custom_field']['unique_code'])) {
                                $payable = $payable - $payment_details['custom_field']['unique_code'];
                            }
                        @endphp

                        <div class="total-row">
                            <span class="total-row-label">{{ get_phrase('Subtotal') }}</span>
                            <span class="total-row-value">{{ currency($payable) }}</span>
                        </div>

                        @isset($payment_details['coupon'])
                            <div class="total-row highlight">
                                <span class="total-row-label">{{ get_phrase('Coupon') }} ({{ $payment_details['coupon'] }})</span>
                                <span class="total-row-value">- {{ currency($payment_details['custom_field']['coupon_discount']) }}</span>
                            </div>
                        @endisset

                        @if ($payment_details['tax'] > 0)
                            <div class="total-row">
                                <span class="total-row-label">{{ get_phrase('Tax') }}</span>
                                <span class="total-row-value">+ {{ currency($payment_details['tax']) }}</span>
                            </div>
                        @endif

                        @if (isset($payment_details['custom_field']['unique_code']))
                            <div class="total-row highlight">
                                <span class="total-row-label">{{ get_phrase('Kode Unik') }}</span>
                                <span class="total-row-value">+ {{ currency($payment_details['custom_field']['unique_code']) }}</span>
                            </div>
                        @endif

                        <div class="total-row grand-total">
                            <span class="total-row-label">{{ get_phrase('Grand Total') }}</span>
                            <span class="total-row-value">{{ currency($payment_details['payable_amount']) }}</span>
                        </div>
                    </div>

                    <!-- Payment Form Container -->
                    <div id="payment-form-container" class="payment-form-container">
                        <!-- Payment gateway forms will be loaded here via AJAX -->
                    </div>

                    <!-- Actions -->
                    <div class="checkout-actions">
                        <a href="{{ $payment_details['cancel_url'] }}" class="btn-checkout btn-checkout-secondary">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                            {{ get_phrase('Cancel') }}
                        </a>
                        <button type="button" id="proceed-payment-btn" class="btn-checkout btn-checkout-primary">
                            {{ get_phrase('Proceed to Payment') }}
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let selectedGateway = '{{ $payment_gateways->first()->identifier ?? "" }}';

    function selectPaymentMethod(identifier) {
        // Remove active class from all methods
        document.querySelectorAll('.payment-method').forEach(method => {
            method.classList.remove('active');
        });

        // Add active class to selected method
        document.getElementById(identifier + '-tab').classList.add('active');
        selectedGateway = identifier;

        // Load payment gateway form
        showPaymentGatewayByAjax(identifier);
    }

    function showPaymentGatewayByAjax(identifier) {
        $.ajax({
            url: "{{ route('payment.show_payment_gateway_by_ajax', '') }}/" + identifier,
            type: 'GET',
            success: function(response) {
                $('#payment-form-container').html(response);
                $('#payment-form-container').addClass('active');
            },
            error: function() {
                alert('{{ get_phrase("Failed to load payment gateway") }}');
            }
        });
    }

    // Load first payment gateway on page load
    $(document).ready(function() {
        if (selectedGateway) {
            showPaymentGatewayByAjax(selectedGateway);
        }

        // Handle proceed payment button
        $('#proceed-payment-btn').click(function() {
            // Trigger the payment form submission
            $('#payment-form-container form').submit();
        });
    });
</script>
@endsection

@push('js')
@include('frontend.default.toaster')
@endpush
