<script type="text/javascript">
    "use strict";

	function pay_success(message){
        success(message);
    }
</script>